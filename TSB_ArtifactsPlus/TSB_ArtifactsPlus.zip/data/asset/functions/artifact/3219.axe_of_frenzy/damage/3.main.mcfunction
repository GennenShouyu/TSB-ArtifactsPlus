#> asset:artifact/3219.axe_of_frenzy/damage/3.main
#
# 神器のメイン処理部
#
# @within function asset:artifact/3219.axe_of_frenzy/damage/2.check_condition

# 基本的な使用時の処理(MP消費や使用回数の処理など)を行う
    # function asset:artifact/common/use/hotbar

# ここから先は神器側の効果の処理を書く

# チャージを+1
    scoreboard players add @s 1A0.Charge 1

# エフェクトのスタック更新など
    function asset:artifact/3219.axe_of_frenzy/damage/update_stack
