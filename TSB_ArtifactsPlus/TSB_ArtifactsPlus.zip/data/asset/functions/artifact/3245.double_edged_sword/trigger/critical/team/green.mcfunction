# 発行エフェクトの色変更用チーム
    team leave @e[tag=1B9.Target]
    team join color_green @e[tag=1B9.Target]