#> asset:artifact/3226.sunk_heart/trigger/2.check_condition
#
# 神器の発動条件をチェックします
#
# @within function asset:artifact/3226.sunk_heart/trigger/1.trigger

# ID指定する
    data modify storage asset:artifact TargetID set value 3226
# 神器の基本的な条件の確認を行うfunction、成功している場合CanUsedタグが付く
    function asset:artifact/common/check_condition/hotbar
# 他にアイテム等確認する場合はここに書く

# CanUsedでかつ、既に装備済ならCanUsedを削除
    execute if entity @s[tag=CanUsed,tag=1A2.Equip] run tag @s remove CanUsed

# CanUsedタグをチェックして3.main.mcfunctionを実行する
    execute if entity @s[tag=CanUsed] run function asset:artifact/3226.sunk_heart/trigger/3.main
