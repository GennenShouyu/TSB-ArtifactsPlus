#> asset:artifact/3267.chill_gale_knife/trigger/vfx/slash3
#
#
#
# @within function asset:artifact/3267.chill_gale_knife/trigger/3.main

# 演出
    playsound minecraft:entity.witch.throw player @a ~ ~ ~ 1 1.2
    playsound minecraft:item.trident.throw player @a ~ ~ ~ 1 1
    playsound minecraft:item.axe.scrape player @a ~ ~ ~ 1 2

# 斬撃
    data modify storage api: Argument.ID set value 2001
    data modify storage api: Argument.FieldOverride set value {Color:3468221,Frames:[20335,20336,20337],Scale:[4f,4f,0.1f],Transformation:{left_rotation:[0.271f,-0.653f,0.271f,0.653f],right_rotation:[0f,0f,0f,1f],translation:[0f,0f,0f]}}
    execute positioned ^ ^ ^1.5 positioned ~ ~-0.5 ~ run function api:object/summon
