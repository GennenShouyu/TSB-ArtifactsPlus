#> asset:artifact/3235.shaker_fries/trigger/2.check_condition
#
# 神器の発動条件をチェックします
#
# @within function asset:artifact/3235.shaker_fries/trigger/1.trigger

#> Private
# @private
    #declare score_holder $RotationY
    #declare score_holder $Diff

# ID指定する
    data modify storage asset:artifact TargetID set value 3235
# 神器の基本的な条件の確認を行うfunction、成功している場合CanUsedタグが付く
    function asset:artifact/common/check_condition/offhand
# 他にアイテム等確認する場合はここに書く

# Yのrotationを取得
    execute store result score $RotationY Temporary run data get entity @s Rotation[1]

# 差分を取得
    execute store result score $Diff Temporary run scoreboard players operation @s LE.OldRotationY -= $RotationY Temporary

# 負の値だった場合正の値にする
    execute if score $Diff Temporary matches ..-1 run scoreboard players operation $Diff Temporary *= $-1 Const

# 差が29以下ならCanUsedを削除
    execute if score $Diff Temporary matches ..29 run tag @s remove CanUsed

# リセット等
    scoreboard players operation @s LE.OldRotationY = $RotationY Temporary
    scoreboard players reset $Diff Temporary
    scoreboard players reset $RotationY Temporary


# CanUsedタグをチェックして3.main.mcfunctionを実行する
    execute if entity @s[tag=CanUsed] run function asset:artifact/3235.shaker_fries/tick/3.main