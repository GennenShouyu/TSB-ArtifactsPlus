#> asset:artifact/3268.harp_crossbow/trigger/2.check_condition/check_bamboo
#
# 竹を所持しているかチェック
#
# @within function asset:artifact/3268.harp_crossbow/trigger/2.check_condition

#> Private
# @private
    #declare score_holder $Count

# 持ってないなら
    execute store result score $Count Temporary run clear @s arrow 0
    execute if score $Count Temporary matches 0 run tag @s remove CanUsed
    execute if score $Count Temporary matches 0 run function lib:message/artifact/dont_have_require_items
    scoreboard players reset $Count Temporary
