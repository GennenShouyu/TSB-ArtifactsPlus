#> asset:artifact/3204.real_knife/trigger/3.main
#
# 神器のメイン処理部
#
# @within function asset:artifact/3204.real_knife/trigger/2.check_condition

#> Private
# @private
    #declare score_holder $Random

# 基本的な使用時の処理(MP消費や使用回数の処理など)を行う
    function asset:artifact/common/use/mainhand

# ここから先は神器側の効果の処理を書く

# 確率でダメージ増加
    # 疑似乱数取得
        execute store result score $Random Temporary run random value 0..8
    # 増加
        execute if score $Random Temporary matches 0 at @e[type=#lib:living,type=!player,tag=Victim,tag=!Uninterferable] run function asset:artifact/3204.real_knife/trigger/check_angel
    # 通常攻撃
        execute if score $Random Temporary matches 1..8 at @e[type=#lib:living,type=!player,tag=Victim] run function asset:artifact/3204.real_knife/trigger/attack
    # リセット
        scoreboard players reset $Random Temporary
