#> asset:artifact/3270.fang_of_frost/give/1.trigger
#
# 神器の取得処理の呼び出し時に実行されるfunction
#
# @within tag/function asset:artifact/give

execute if data storage asset:context {id:3270} run function asset:artifact/3270.fang_of_frost/give/2.give
