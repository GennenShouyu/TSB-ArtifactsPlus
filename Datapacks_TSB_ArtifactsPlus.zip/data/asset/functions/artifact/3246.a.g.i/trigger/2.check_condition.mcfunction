#> asset:artifact/3246.a.g.i/trigger/2.check_condition
#
# 神器の発動条件をチェックします
#
# @within function asset:artifact/3246.a.g.i/trigger/1.trigger

#> Private
# @private
    #declare score_holder $MPPer

# 神器の基本的な条件の確認を行うfunction、成功している場合CanUsedタグが付く
    function asset:artifact/common/check_condition/offhand
# 他にアイテム等確認する場合はここに書く

# 敵がいるかみる
    execute unless entity @e[type=#lib:living,type=!player,tag=Enemy,tag=!Uninterferable,distance=..9] run tag @s remove CanUsed

# CanUsedタグをチェックして3.main.mcfunctionを実行する
    execute if entity @s[tag=CanUsed] run function asset:artifact/3246.a.g.i/trigger/3.main
